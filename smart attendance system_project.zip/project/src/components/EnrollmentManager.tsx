import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { UserPlus, X } from 'lucide-react';

interface Student {
  id: string;
  student_id: string;
  first_name: string;
  last_name: string;
}

interface Enrollment {
  id: string;
  student_id: string;
  students: Student;
}

interface EnrollmentManagerProps {
  classId: string;
  onClose: () => void;
}

export function EnrollmentManager({ classId, onClose }: EnrollmentManagerProps) {
  const [allStudents, setAllStudents] = useState<Student[]>([]);
  const [enrolledStudents, setEnrolledStudents] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [classId]);

  const loadData = async () => {
    try {
      const [studentsResult, enrollmentsResult] = await Promise.all([
        supabase.from('students').select('*').order('last_name, first_name'),
        supabase
          .from('class_enrollments')
          .select('id, student_id, students(id, student_id, first_name, last_name)')
          .eq('class_id', classId),
      ]);

      if (studentsResult.error) throw studentsResult.error;
      if (enrollmentsResult.error) throw enrollmentsResult.error;

      setAllStudents(studentsResult.data || []);
      const enrolled = new Set(
        (enrollmentsResult.data || []).map((e: Enrollment) => e.student_id)
      );
      setEnrolledStudents(enrolled);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEnroll = async (studentId: string) => {
    try {
      const { error } = await supabase
        .from('class_enrollments')
        .insert([{ class_id: classId, student_id: studentId }]);

      if (error) throw error;
      setEnrolledStudents((prev) => new Set([...prev, studentId]));
    } catch (error) {
      console.error('Error enrolling student:', error);
    }
  };

  const handleUnenroll = async (studentId: string) => {
    try {
      const { error } = await supabase
        .from('class_enrollments')
        .delete()
        .eq('class_id', classId)
        .eq('student_id', studentId);

      if (error) throw error;
      setEnrolledStudents((prev) => {
        const newSet = new Set(prev);
        newSet.delete(studentId);
        return newSet;
      });
    } catch (error) {
      console.error('Error unenrolling student:', error);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-xl p-6 max-w-2xl w-full mx-4">
          <div className="text-center py-8">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Manage Enrollments</h3>
          <button
            onClick={onClose}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1">
          {allStudents.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              No students available. Add students first.
            </div>
          ) : (
            <div className="space-y-2">
              {allStudents.map((student) => {
                const isEnrolled = enrolledStudents.has(student.id);
                return (
                  <div
                    key={student.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <div>
                      <div className="font-medium text-gray-900">
                        {student.first_name} {student.last_name}
                      </div>
                      <div className="text-sm text-gray-500 font-mono">{student.student_id}</div>
                    </div>
                    {isEnrolled ? (
                      <button
                        onClick={() => handleUnenroll(student.id)}
                        className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                      >
                        <X className="w-4 h-4" />
                        Remove
                      </button>
                    ) : (
                      <button
                        onClick={() => handleEnroll(student.id)}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                      >
                        <UserPlus className="w-4 h-4" />
                        Enroll
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
