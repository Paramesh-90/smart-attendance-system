import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogOut, Users, BookOpen, Calendar, BarChart3 } from 'lucide-react';
import { ClassesView } from './ClassesView';
import { StudentsView } from './StudentsView';
import { AttendanceView } from './AttendanceView';
import { ReportsView } from './ReportsView';

type View = 'classes' | 'students' | 'attendance' | 'reports';

export function Dashboard() {
  const [currentView, setCurrentView] = useState<View>('classes');
  const { signOut, user } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const navigation = [
    { id: 'classes' as View, name: 'Classes', icon: BookOpen },
    { id: 'students' as View, name: 'Students', icon: Users },
    { id: 'attendance' as View, name: 'Attendance', icon: Calendar },
    { id: 'reports' as View, name: 'Reports', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Smart Attendance</h1>
                <p className="text-xs text-gray-500">{user?.email}</p>
              </div>
            </div>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
                  currentView === item.id
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.name}
              </button>
            );
          })}
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          {currentView === 'classes' && <ClassesView />}
          {currentView === 'students' && <StudentsView />}
          {currentView === 'attendance' && <AttendanceView />}
          {currentView === 'reports' && <ReportsView />}
        </div>
      </div>
    </div>
  );
}
