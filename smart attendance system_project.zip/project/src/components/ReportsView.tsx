import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { BarChart3, TrendingUp, Users, Calendar } from 'lucide-react';

interface Class {
  id: string;
  name: string;
  code: string;
}

interface AttendanceStats {
  studentName: string;
  studentId: string;
  present: number;
  absent: number;
  late: number;
  excused: number;
  total: number;
  attendanceRate: number;
}

export function ReportsView() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0],
  });
  const [stats, setStats] = useState<AttendanceStats[]>([]);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState({
    totalStudents: 0,
    avgAttendanceRate: 0,
    totalClasses: 0,
  });

  useEffect(() => {
    loadClasses();
  }, []);

  useEffect(() => {
    if (selectedClass) {
      loadReport();
    }
  }, [selectedClass, dateRange]);

  const loadClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('classes')
        .select('id, name, code')
        .order('name');

      if (error) throw error;
      setClasses(data || []);
    } catch (error) {
      console.error('Error loading classes:', error);
    }
  };

  const loadReport = async () => {
    if (!selectedClass) return;
    setLoading(true);

    try {
      const { data: enrollments, error: enrollError } = await supabase
        .from('class_enrollments')
        .select('student_id, students(id, student_id, first_name, last_name)')
        .eq('class_id', selectedClass);

      if (enrollError) throw enrollError;

      const { data: attendanceRecords, error: attendanceError } = await supabase
        .from('attendance_records')
        .select('*')
        .eq('class_id', selectedClass)
        .gte('date', dateRange.start)
        .lte('date', dateRange.end);

      if (attendanceError) throw attendanceError;

      const studentStats: Record<string, AttendanceStats> = {};

      enrollments?.forEach((enrollment: any) => {
        const student = enrollment.students;
        if (student) {
          studentStats[student.id] = {
            studentName: `${student.first_name} ${student.last_name}`,
            studentId: student.student_id,
            present: 0,
            absent: 0,
            late: 0,
            excused: 0,
            total: 0,
            attendanceRate: 0,
          };
        }
      });

      attendanceRecords?.forEach((record) => {
        if (studentStats[record.student_id]) {
          studentStats[record.student_id][record.status]++;
          studentStats[record.student_id].total++;
        }
      });

      Object.keys(studentStats).forEach((studentId) => {
        const stat = studentStats[studentId];
        if (stat.total > 0) {
          stat.attendanceRate = ((stat.present + stat.late) / stat.total) * 100;
        }
      });

      const statsArray = Object.values(studentStats).sort((a, b) =>
        a.studentName.localeCompare(b.studentName)
      );

      setStats(statsArray);

      const totalStudents = statsArray.length;
      const avgRate =
        totalStudents > 0
          ? statsArray.reduce((sum, s) => sum + s.attendanceRate, 0) / totalStudents
          : 0;

      setSummary({
        totalStudents,
        avgAttendanceRate: avgRate,
        totalClasses: statsArray[0]?.total || 0,
      });
    } catch (error) {
      console.error('Error loading report:', error);
    } finally {
      setLoading(false);
    }
  };

  const getAttendanceColor = (rate: number) => {
    if (rate >= 90) return 'text-green-600';
    if (rate >= 75) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-1">Reports & Analytics</h2>
        <p className="text-gray-600">View attendance statistics and trends</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Choose a class...</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.id}>
                {cls.name} ({cls.code})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {!selectedClass ? (
        <div className="text-center py-12">
          <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">Select a class to view reports</p>
        </div>
      ) : loading ? (
        <div className="text-center py-8 text-gray-500">Loading report...</div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 border border-blue-200">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{summary.totalStudents}</div>
              <div className="text-sm text-gray-600">Total Students</div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-6 border border-green-200">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">
                {summary.avgAttendanceRate.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-600">Average Attendance</div>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-6 border border-orange-200">
              <div className="flex items-center justify-between mb-2">
                <Calendar className="w-8 h-8 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{summary.totalClasses}</div>
              <div className="text-sm text-gray-600">Sessions Tracked</div>
            </div>
          </div>

          {stats.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No attendance data for selected period</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                      Student
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Present
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Late
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Absent
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Excused
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">
                      Total
                    </th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                      Rate
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {stats.map((stat, index) => (
                    <tr
                      key={index}
                      className="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                    >
                      <td className="py-4 px-4">
                        <div className="font-medium text-gray-900">{stat.studentName}</div>
                        <div className="text-sm text-gray-500 font-mono">{stat.studentId}</div>
                      </td>
                      <td className="text-center py-4 px-4">
                        <span className="inline-flex items-center justify-center w-10 h-10 bg-green-100 text-green-700 rounded-lg font-semibold">
                          {stat.present}
                        </span>
                      </td>
                      <td className="text-center py-4 px-4">
                        <span className="inline-flex items-center justify-center w-10 h-10 bg-yellow-100 text-yellow-700 rounded-lg font-semibold">
                          {stat.late}
                        </span>
                      </td>
                      <td className="text-center py-4 px-4">
                        <span className="inline-flex items-center justify-center w-10 h-10 bg-red-100 text-red-700 rounded-lg font-semibold">
                          {stat.absent}
                        </span>
                      </td>
                      <td className="text-center py-4 px-4">
                        <span className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 text-blue-700 rounded-lg font-semibold">
                          {stat.excused}
                        </span>
                      </td>
                      <td className="text-center py-4 px-4 font-semibold text-gray-900">
                        {stat.total}
                      </td>
                      <td className="text-right py-4 px-4">
                        <span
                          className={`text-lg font-bold ${getAttendanceColor(stat.attendanceRate)}`}
                        >
                          {stat.attendanceRate.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
