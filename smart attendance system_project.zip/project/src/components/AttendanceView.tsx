import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, Check, X, Clock, FileText } from 'lucide-react';

interface Class {
  id: string;
  name: string;
  code: string;
}

interface Student {
  id: string;
  student_id: string;
  first_name: string;
  last_name: string;
}

interface AttendanceRecord {
  id?: string;
  student_id: string;
  status: 'present' | 'absent' | 'late' | 'excused';
  notes: string;
}

export function AttendanceView() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState<Record<string, AttendanceRecord>>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    loadClasses();
  }, []);

  useEffect(() => {
    if (selectedClass) {
      loadStudentsAndAttendance();
    }
  }, [selectedClass, selectedDate]);

  const loadClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('classes')
        .select('id, name, code')
        .order('name');

      if (error) throw error;
      setClasses(data || []);
    } catch (error) {
      console.error('Error loading classes:', error);
    }
  };

  const loadStudentsAndAttendance = async () => {
    if (!selectedClass) return;
    setLoading(true);

    try {
      const { data: enrollments, error: enrollError } = await supabase
        .from('class_enrollments')
        .select('student_id, students(id, student_id, first_name, last_name)')
        .eq('class_id', selectedClass);

      if (enrollError) throw enrollError;

      const studentsList = enrollments?.map((e: any) => e.students).filter(Boolean) || [];
      setStudents(studentsList);

      const { data: attendanceData, error: attendanceError } = await supabase
        .from('attendance_records')
        .select('*')
        .eq('class_id', selectedClass)
        .eq('date', selectedDate);

      if (attendanceError) throw attendanceError;

      const attendanceMap: Record<string, AttendanceRecord> = {};
      attendanceData?.forEach((record) => {
        attendanceMap[record.student_id] = {
          id: record.id,
          student_id: record.student_id,
          status: record.status,
          notes: record.notes || '',
        };
      });

      studentsList.forEach((student: Student) => {
        if (!attendanceMap[student.id]) {
          attendanceMap[student.id] = {
            student_id: student.id,
            status: 'absent',
            notes: '',
          };
        }
      });

      setAttendance(attendanceMap);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateAttendance = (studentId: string, field: keyof AttendanceRecord, value: string) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [field]: value,
      },
    }));
  };

  const handleSave = async () => {
    if (!selectedClass || !user) return;
    setSaving(true);

    try {
      const records = Object.values(attendance).map((record) => ({
        class_id: selectedClass,
        student_id: record.student_id,
        date: selectedDate,
        status: record.status,
        notes: record.notes || null,
        marked_by: user.id,
      }));

      for (const record of records) {
        if (attendance[record.student_id].id) {
          await supabase
            .from('attendance_records')
            .update({
              status: record.status,
              notes: record.notes,
              updated_at: new Date().toISOString(),
            })
            .eq('id', attendance[record.student_id].id!);
        } else {
          await supabase.from('attendance_records').insert([record]);
        }
      }

      await loadStudentsAndAttendance();
    } catch (error) {
      console.error('Error saving attendance:', error);
    } finally {
      setSaving(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'absent':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'late':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'excused':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'present':
        return <Check className="w-4 h-4" />;
      case 'absent':
        return <X className="w-4 h-4" />;
      case 'late':
        return <Clock className="w-4 h-4" />;
      case 'excused':
        return <FileText className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-1">Attendance</h2>
        <p className="text-gray-600">Mark attendance for your classes</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Choose a class...</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.id}>
                {cls.name} ({cls.code})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {!selectedClass ? (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">Select a class to mark attendance</p>
        </div>
      ) : loading ? (
        <div className="text-center py-8 text-gray-500">Loading students...</div>
      ) : students.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No students enrolled in this class</p>
          <p className="text-gray-400 mt-2">Add students to the class first</p>
        </div>
      ) : (
        <>
          <div className="space-y-3 mb-6">
            {students.map((student) => {
              const record = attendance[student.id];
              return (
                <div key={student.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
                    <div className="md:col-span-3">
                      <div className="font-medium text-gray-900">
                        {student.first_name} {student.last_name}
                      </div>
                      <div className="text-sm text-gray-500 font-mono">{student.student_id}</div>
                    </div>

                    <div className="md:col-span-5 flex flex-wrap gap-2">
                      {(['present', 'absent', 'late', 'excused'] as const).map((status) => (
                        <button
                          key={status}
                          onClick={() => updateAttendance(student.id, 'status', status)}
                          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all capitalize border ${
                            record?.status === status
                              ? getStatusColor(status)
                              : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                          }`}
                        >
                          {getStatusIcon(status)}
                          {status}
                        </button>
                      ))}
                    </div>

                    <div className="md:col-span-4">
                      <input
                        type="text"
                        value={record?.notes || ''}
                        onChange={(e) => updateAttendance(student.id, 'notes', e.target.value)}
                        placeholder="Notes (optional)"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleSave}
              disabled={saving}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? 'Saving...' : 'Save Attendance'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
