/*
  # Smart Attendance System Schema

  1. New Tables
    - `classes`
      - `id` (uuid, primary key)
      - `name` (text) - Class name (e.g., "Computer Science 101")
      - `code` (text) - Class code (e.g., "CS101")
      - `description` (text, nullable)
      - `teacher_id` (uuid) - References auth.users
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `students`
      - `id` (uuid, primary key)
      - `student_id` (text, unique) - Student ID number
      - `first_name` (text)
      - `last_name` (text)
      - `email` (text, nullable)
      - `phone` (text, nullable)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `class_enrollments`
      - `id` (uuid, primary key)
      - `class_id` (uuid) - References classes
      - `student_id` (uuid) - References students
      - `enrolled_at` (timestamptz)
      - Unique constraint on (class_id, student_id)
    
    - `attendance_records`
      - `id` (uuid, primary key)
      - `class_id` (uuid) - References classes
      - `student_id` (uuid) - References students
      - `date` (date)
      - `status` (text) - 'present', 'absent', 'late', 'excused'
      - `notes` (text, nullable)
      - `marked_by` (uuid) - References auth.users
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - Unique constraint on (class_id, student_id, date)

  2. Security
    - Enable RLS on all tables
    - Authenticated users can manage their own classes
    - Authenticated users can view and mark attendance for their classes
    - Authenticated users can manage students enrolled in their classes

  3. Indexes
    - Index on attendance_records(class_id, date) for quick lookups
    - Index on class_enrollments(class_id) for enrollment queries
    - Index on students(student_id) for quick student lookup
*/

CREATE TABLE IF NOT EXISTS classes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  description text,
  teacher_id uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id text NOT NULL UNIQUE,
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS class_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid REFERENCES classes(id) ON DELETE CASCADE NOT NULL,
  student_id uuid REFERENCES students(id) ON DELETE CASCADE NOT NULL,
  enrolled_at timestamptz DEFAULT now(),
  UNIQUE(class_id, student_id)
);

CREATE TABLE IF NOT EXISTS attendance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid REFERENCES classes(id) ON DELETE CASCADE NOT NULL,
  student_id uuid REFERENCES students(id) ON DELETE CASCADE NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  status text NOT NULL CHECK (status IN ('present', 'absent', 'late', 'excused')),
  notes text,
  marked_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(class_id, student_id, date)
);

CREATE INDEX IF NOT EXISTS idx_attendance_class_date ON attendance_records(class_id, date);
CREATE INDEX IF NOT EXISTS idx_enrollments_class ON class_enrollments(class_id);
CREATE INDEX IF NOT EXISTS idx_students_student_id ON students(student_id);

ALTER TABLE classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE class_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Teachers can view their own classes"
  ON classes FOR SELECT
  TO authenticated
  USING (auth.uid() = teacher_id);

CREATE POLICY "Teachers can create their own classes"
  ON classes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Teachers can update their own classes"
  ON classes FOR UPDATE
  TO authenticated
  USING (auth.uid() = teacher_id)
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Teachers can delete their own classes"
  ON classes FOR DELETE
  TO authenticated
  USING (auth.uid() = teacher_id);

CREATE POLICY "Authenticated users can view all students"
  ON students FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create students"
  ON students FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update students"
  ON students FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete students"
  ON students FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Teachers can view enrollments for their classes"
  ON class_enrollments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = class_enrollments.class_id
      AND classes.teacher_id = auth.uid()
    )
  );

CREATE POLICY "Teachers can create enrollments for their classes"
  ON class_enrollments FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = class_enrollments.class_id
      AND classes.teacher_id = auth.uid()
    )
  );

CREATE POLICY "Teachers can delete enrollments from their classes"
  ON class_enrollments FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = class_enrollments.class_id
      AND classes.teacher_id = auth.uid()
    )
  );

CREATE POLICY "Teachers can view attendance for their classes"
  ON attendance_records FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = attendance_records.class_id
      AND classes.teacher_id = auth.uid()
    )
  );

CREATE POLICY "Teachers can mark attendance for their classes"
  ON attendance_records FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = marked_by AND
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = attendance_records.class_id
      AND classes.teacher_id = auth.uid()
    )
  );

CREATE POLICY "Teachers can update attendance for their classes"
  ON attendance_records FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = attendance_records.class_id
      AND classes.teacher_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = attendance_records.class_id
      AND classes.teacher_id = auth.uid()
    )
  );

CREATE POLICY "Teachers can delete attendance for their classes"
  ON attendance_records FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM classes
      WHERE classes.id = attendance_records.class_id
      AND classes.teacher_id = auth.uid()
    )
  );